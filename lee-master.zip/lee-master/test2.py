import modfile
print modfile.s
print modfile.add(5,6)

