import sys
print(sys.version)

