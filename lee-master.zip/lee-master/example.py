import os

print "hello world from python"
