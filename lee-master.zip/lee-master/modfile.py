s = 'module file sample'

def add(a,b):
    return a+b

print add(3,4)

